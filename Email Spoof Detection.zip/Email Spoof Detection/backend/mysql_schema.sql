CREATE DATABASE IF NOT EXISTS email_spoof_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE email_spoof_db;

CREATE TABLE IF NOT EXISTS suspicious_emails (
  id INT AUTO_INCREMENT PRIMARY KEY,
  message_id VARCHAR(255),
  subject VARCHAR(512),
  sender VARCHAR(255),
  from_header VARCHAR(255),
  to_header VARCHAR(255),
  received_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  score INT DEFAULT 0,
  reasons TEXT,
  stored_path VARCHAR(1024),
  is_deleted TINYINT(1) DEFAULT 0,
  user_notified TINYINT(1) DEFAULT 0,
  reminders_sent INT DEFAULT 0,
  UNIQUE KEY uq_message_id (message_id)
);

CREATE TABLE IF NOT EXISTS action_logs (
  id INT AUTO_INCREMENT PRIMARY KEY,
  email_id INT,
  action VARCHAR(128),
  detail TEXT,
  timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
);