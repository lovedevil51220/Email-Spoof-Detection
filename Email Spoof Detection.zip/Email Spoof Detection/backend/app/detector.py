import re
from email import message_from_string
from email.header import decode_header
from .schemas import IncomingEmail
from typing import Tuple, List
from .config import STORAGE_PATH
import os
import json
import hashlib

def simple_decode_header(hdr_bytes):
    if hdr_bytes is None:
        return None
    parts = decode_header(hdr_bytes)
    result = ""
    for part, enc in parts:
        if isinstance(part, bytes):
            try:
                result += part.decode(enc or 'utf-8', errors='ignore')
            except:
                result += part.decode('utf-8', errors='ignore')
        else:
            result += part
    return result

def compute_score_and_reasons(raw_email: str) -> Tuple[int, List[str]]:
    """
    Basic heuristic scoring:
    - missing or failing SPF/DKIM (not checked in headers here but we look for Authentication-Results)
    - mismatch between From and Return-Path / Sender
    - suspicious subject (URGENT / ACTION REQUIRED)
    - suspicious links or domain mismatches (basic)
    - forged message-id
    """
    score = 0
    reasons = []
    try:
        msg = message_from_string(raw_email)
    except Exception:
        msg = None

    # Look for Authentication-Results
    auth_results = ""
    if msg:
        auth_results = msg.get('Authentication-Results', '') or ''
        if 'spf=pass' not in auth_results.lower():
            score += 2
            reasons.append("SPF not seen as pass in Authentication-Results")
        if 'dkim=pass' not in auth_results.lower():
            score += 2
            reasons.append("DKIM not seen as pass in Authentication-Results")

    # From vs Return-Path / Sender mismatch
    from_hdr = msg.get('From', '') if msg else ''
    return_path = msg.get('Return-Path', '') if msg else ''
    sender = msg.get('Sender', '') if msg else ''
    if from_hdr and return_path and (extract_domain(from_hdr) != extract_domain(return_path)):
        score += 3
        reasons.append("From domain differs from Return-Path domain")
    if sender and from_hdr and (extract_domain(sender) != extract_domain(from_hdr)):
        score += 2
        reasons.append("Sender header domain differs from From header domain")

    # Subject heuristics
    subject = msg.get('Subject', '') if msg else ''
    if re.search(r'\b(urgent|action required|password|verify|verify your|reset)\b', subject, re.I):
        score += 2
        reasons.append("Subject contains urgent/verification keywords")

    # Links domain mismatch (very simple)
    payload = ''
    if msg:
        if msg.is_multipart():
            for part in msg.walk():
                if part.get_content_type() == 'text/plain':
                    try:
                        payload += part.get_payload(decode=True).decode(errors='ignore')
                    except:
                        pass
        else:
            try:
                payload += msg.get_payload(decode=True).decode(errors='ignore')
            except:
                pass
    urls = re.findall(r'https?://[^\s\'"<>]+', payload)
    for url in urls[:5]:
        host = extract_domain_from_url(url)
        if host and from_hdr and extract_domain(from_hdr) and host != extract_domain(from_hdr):
            score += 1
            reasons.append(f"Link host {host} does not match From domain")

    # Message-ID suspicious?
    mid = msg.get('Message-ID', '') if msg else ''
    if not mid or '<' not in mid:
        score += 1
        reasons.append("Missing or malformed Message-ID")

    # Final normalization
    if score == 0:
        reasons.append("No clear suspicious indicators found")
    return score, reasons

def extract_domain(header_value: str) -> str:
    # crude extract domain from an email-like string
    if not header_value:
        return ""
    m = re.search(r'@([A-Za-z0-9.-]+)', header_value)
    if m:
        return m.group(1).lower()
    # fallback to host in angle brackets if present
    m2 = re.search(r'@([A-Za-z0-9.-]+)>', header_value)
    if m2:
        return m2.group(1).lower()
    return ""

def extract_domain_from_url(url: str) -> str:
    m = re.search(r'https?://([^/]+)/?', url)
    if m:
        host = m.group(1).lower()
        return host.split(':')[0]
    return ""

def store_raw_email(raw_email: str, subject: str = None) -> str:
    # store raw email as hashed filename under STORAGE_PATH
    os.makedirs(STORAGE_PATH, exist_ok=True)
    key = hashlib.sha256((raw_email + (subject or "")).encode('utf-8')).hexdigest()
    filename = f"{key}.eml"
    path = os.path.join(STORAGE_PATH, filename)
    with open(path, "w", encoding="utf-8") as f:
        f.write(raw_email)
    # also write JSON metadata
    meta = {"path": path}
    with open(path + ".meta.json", "w", encoding="utf-8") as f:
        json.dump(meta, f)
    return path