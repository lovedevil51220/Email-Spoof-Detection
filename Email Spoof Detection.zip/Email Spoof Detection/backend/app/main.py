from fastapi import FastAPI, Depends, HTTPException, BackgroundTasks
from .database import get_db, Base, engine
from . import models, detector, email_utils
from .schemas import IncomingEmail, EmailResponse
from sqlalchemy.orm import Session
from .crons import schedule_jobs
import os

app = FastAPI(title="Email Spoof Detection API")

# create tables if not exist
Base.metadata.create_all(bind=engine)

# start scheduled jobs
schedule_jobs()

@app.post("/ingest", response_model=EmailResponse)
def ingest_email(payload: IncomingEmail, background_tasks: BackgroundTasks, db: Session = Depends(get_db)):
    # If raw is provided, run heuristic detection
    raw = payload.raw or ""
    # if raw is empty, create minimal synthetic raw for storage
    if not raw:
        raw = f"Subject: {payload.subject or ''}\nFrom: {payload.from_header or payload.sender or ''}\n\n{payload.body_preview or ''}"

    score, reasons = detector.compute_score_and_reasons(raw)
    reasons_text = "\n".join(reasons)
    stored_path = detector.store_raw_email(raw, payload.subject)
    # persist
    db_email = models.SuspiciousEmail(
        message_id=payload.message_id,
        subject=payload.subject,
        sender=payload.sender,
        from_header=payload.from_header,
        to_header=payload.to_header,
        score=score,
        reasons=reasons_text,
        stored_path=stored_path
    )
    db.add(db_email)
    db.commit()
    db.refresh(db_email)
    # optionally notify user now or later; here we mark user_notified False and let cron handle reminders
    return EmailResponse(
        id=db_email.id,
        message_id=db_email.message_id,
        subject=db_email.subject,
        sender=db_email.sender,
        from_header=db_email.from_header,
        score=db_email.score,
        reasons=db_email.reasons,
        stored_path=db_email.stored_path,
        reminders_sent=db_email.reminders_sent,
        is_deleted=db_email.is_deleted
    )

@app.get("/emails/{email_id}", response_model=EmailResponse)
def get_email(email_id: int, db: Session = Depends(get_db)):
    e = db.get(models.SuspiciousEmail, email_id)
    if not e:
        raise HTTPException(status_code=404, detail="Not found")
    return EmailResponse(
        id=e.id,
        message_id=e.message_id,
        subject=e.subject,
        sender=e.sender,
        from_header=e.from_header,
        score=e.score,
        reasons=e.reasons,
        stored_path=e.stored_path,
        reminders_sent=e.reminders_sent,
        is_deleted=e.is_deleted
    )

@app.get("/emails", response_model=list[EmailResponse])
def list_emails(db: Session = Depends(get_db)):
    items = db.query(models.SuspiciousEmail).order_by(models.SuspiciousEmail.received_at.desc()).limit(200).all()
    return [EmailResponse(
        id=i.id,
        message_id=i.message_id,
        subject=i.subject,
        sender=i.sender,
        from_header=i.from_header,
        score=i.score,
        reasons=i.reasons,
        stored_path=i.stored_path,
        reminders_sent=i.reminders_sent,
        is_deleted=i.is_deleted
    ) for i in items]

@app.post("/emails/{email_id}/action")
def email_action(email_id: int, action: str, db: Session = Depends(get_db)):
    e = db.get(models.SuspiciousEmail, email_id)
    if not e:
        raise HTTPException(404, "Not found")
    if action == "mark_safe":
        e.is_deleted = False
        e.reminders_sent = 0
        # log
        db.add(models.ActionLog(email_id=email_id, action="marked_safe", detail="User marked safe"))
        db.commit()
        return {"status": "ok"}
    elif action == "delete":
        e.is_deleted = True
        db.add(models.ActionLog(email_id=email_id, action="deleted_by_user", detail="User requested deletion"))
        db.commit()
        # optionally delete stored file
        try:
            if e.stored_path and os.path.exists(e.stored_path):
                os.remove(e.stored_path)
        except Exception:
            pass
        return {"status": "deleted"}
    else:
        raise HTTPException(400, "Unknown action")

@app.post("/report")
def send_report(email_to: str, db: Session = Depends(get_db)):
    # collect top suspicious emails
    rows = db.query(models.SuspiciousEmail).filter(models.SuspiciousEmail.is_deleted == False).order_by(models.SuspiciousEmail.score.desc()).limit(50).all()
    report_rows = [{"id": r.id, "subject": r.subject, "sender": r.sender, "score": r.score, "reasons": r.reasons} for r in rows]
    email_utils.send_report_email(email_to, report_rows)
    return {"status": "report_sent"}