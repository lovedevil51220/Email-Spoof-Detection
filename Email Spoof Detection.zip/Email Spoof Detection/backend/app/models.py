from sqlalchemy import Column, Integer, String, DateTime, Text, Boolean, func
from sqlalchemy.orm import relationship
from .database import Base

class SuspiciousEmail(Base):
    __tablename__ = "suspicious_emails"
    id = Column(Integer, primary_key=True, index=True)
    message_id = Column(String(255), unique=True, nullable=True)
    subject = Column(String(512), nullable=True)
    sender = Column(String(255), nullable=True)
    from_header = Column(String(255), nullable=True)
    to_header = Column(String(255), nullable=True)
    received_at = Column(DateTime, server_default=func.now())
    score = Column(Integer, default=0)
    reasons = Column(Text, nullable=True)
    stored_path = Column(String(1024), nullable=True)
    is_deleted = Column(Boolean, default=False)
    user_notified = Column(Boolean, default=False)
    reminders_sent = Column(Integer, default=0)

class ActionLog(Base):
    __tablename__ = "action_logs"
    id = Column(Integer, primary_key=True, index=True)
    email_id = Column(Integer, nullable=True)
    action = Column(String(128))
    detail = Column(Text, nullable=True)
    timestamp = Column(DateTime, server_default=func.now())