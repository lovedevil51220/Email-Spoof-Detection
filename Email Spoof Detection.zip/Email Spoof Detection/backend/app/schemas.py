from pydantic import BaseModel, EmailStr
from typing import Optional

class IncomingEmail(BaseModel):
    raw: Optional[str] = None
    message_id: Optional[str] = None
    subject: Optional[str] = None
    from_header: Optional[str] = None
    sender: Optional[str] = None
    to_header: Optional[str] = None
    body_preview: Optional[str] = None

class EmailResponse(BaseModel):
    id: int
    message_id: Optional[str]
    subject: Optional[str]
    sender: Optional[str]
    from_header: Optional[str]
    score: int
    reasons: Optional[str]
    stored_path: Optional[str]
    reminders_sent: int
    is_deleted: bool