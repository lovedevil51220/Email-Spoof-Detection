import smtplib
from email.message import EmailMessage
from .config import SMTP_HOST, SMTP_PORT, SMTP_USER, SMTP_PASS, FROM_EMAIL
from typing import List
from jinja2 import Template

def send_simple_email(to_email: str, subject: str, body: str, html: bool = False):
    msg = EmailMessage()
    msg['From'] = FROM_EMAIL
    msg['To'] = to_email
    msg['Subject'] = subject
    if html:
        msg.add_alternative(body, subtype='html')
    else:
        msg.set_content(body)
    with smtplib.SMTP(SMTP_HOST, SMTP_PORT) as server:
        server.starttls()
        server.login(SMTP_USER, SMTP_PASS)
        server.send_message(msg)

def send_report_email(to_email: str, report_rows: List[dict]):
    # basic html table report
    tpl = Template("""
    <h2>Suspicious Email Report</h2>
    <table border="1" cellpadding="6" cellspacing="0">
      <tr><th>ID</th><th>Subject</th><th>Sender</th><th>Score</th><th>Reasons</th></tr>
      {% for r in rows %}
      <tr>
        <td>{{r.id}}</td><td>{{r.subject}}</td><td>{{r.sender}}</td><td>{{r.score}}</td><td>{{r.reasons}}</td>
      </tr>
      {% endfor %}
    </table>
    """)
    html = tpl.render(rows=report_rows)
    send_simple_email(to_email, "Suspicious Email Report", html, html=True)