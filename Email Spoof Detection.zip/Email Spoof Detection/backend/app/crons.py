from apscheduler.schedulers.background import BackgroundScheduler
from .database import SessionLocal
from .models import SuspiciousEmail, ActionLog
from .email_utils import send_simple_email, send_report_email
from .config import REMINDER_INTERVAL_MINUTES, MAX_REMINDERS, FROM_EMAIL
from sqlalchemy import select, update
import logging

logger = logging.getLogger(__name__)

def schedule_jobs():
    scheduler = BackgroundScheduler()
    scheduler.add_job(send_reminders_and_handle_deletions, 'interval', minutes=REMINDER_INTERVAL_MINUTES)
    scheduler.start()

def send_reminders_and_handle_deletions():
    db = SessionLocal()
    try:
        q = select(SuspiciousEmail).where(SuspiciousEmail.is_deleted == False)
        for row in db.execute(q).scalars().all():
            # Only notify if not yet marked safe and not deleted
            if row.reminders_sent < MAX_REMINDERS:
                # send reminder to FROM_EMAIL or to a stakeholder - in practice send to the mailbox user
                try:
                    send_simple_email(FROM_EMAIL, f"Reminder: action required for suspicious email {row.id}",
                                      f"Please review suspicious email ID {row.id} (subject: {row.subject}). Reminders sent: {row.reminders_sent}")
                    row.reminders_sent += 1
                    db.add(ActionLog(email_id=row.id, action="reminder_sent", detail=f"Reminder #{row.reminders_sent} sent"))
                except Exception as e:
                    logger.exception("Failed to send reminder: %s", e)
            else:
                # auto-delete
                try:
                    row.is_deleted = True
                    db.add(ActionLog(email_id=row.id, action="auto_deleted", detail="Auto-deleted after missed reminders"))
                except Exception as e:
                    logger.exception("Failed to auto-delete record: %s", e)
        db.commit()
    finally:
        db.close()