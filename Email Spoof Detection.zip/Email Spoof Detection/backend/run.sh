#!/usr/bin/env bash
# quick-run script
# export environment variables as needed, then:
uvicorn app.main:app --host 0.0.0.0 --port 8000 --reload