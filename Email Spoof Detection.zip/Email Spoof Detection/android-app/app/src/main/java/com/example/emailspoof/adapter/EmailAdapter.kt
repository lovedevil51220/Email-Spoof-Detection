package com.example.emailspoof.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.emailspoof.R
import com.example.emailspoof.models.SuspiciousEmail

class EmailAdapter(
    private var items: List<SuspiciousEmail>,
    private val onMarkSafe: (SuspiciousEmail) -> Unit,
    private val onDelete: (SuspiciousEmail) -> Unit
) : RecyclerView.Adapter<EmailAdapter.VH>() {

    class VH(view: View): RecyclerView.ViewHolder(view) {
        val tvSubject: TextView = view.findViewById(R.id.tvSubject)
        val tvSender: TextView = view.findViewById(R.id.tvSender)
        val tvScore: TextView = view.findViewById(R.id.tvScore)
        val tvReasons: TextView = view.findViewById(R.id.tvReasons)
        val btnSafe: Button = view.findViewById(R.id.btnSafe)
        val btnDelete: Button = view.findViewById(R.id.btnDelete)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_email, parent, false)
        return VH(v)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val e = items[position]
        holder.tvSubject.text = e.subject ?: "(no subject)"
        holder.tvSender.text = e.sender ?: e.from_header ?: "unknown"
        holder.tvScore.text = "Score: ${e.score}"
        holder.tvReasons.text = e.reasons ?: ""
        holder.btnSafe.setOnClickListener { onMarkSafe(e) }
        holder.btnDelete.setOnClickListener { onDelete(e) }
    }

    override fun getItemCount(): Int = items.size

    fun update(list: List<SuspiciousEmail>) {
        items = list
        notifyDataSetChanged()
    }
}