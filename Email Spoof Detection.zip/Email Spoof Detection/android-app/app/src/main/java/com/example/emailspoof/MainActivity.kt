package com.example.emailspoof

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.emailspoof.adapter.EmailAdapter
import com.example.emailspoof.models.SuspiciousEmail
import kotlinx.coroutines.*
import kotlin.coroutines.CoroutineContext

class MainActivity : AppCompatActivity(), CoroutineScope {
    private lateinit var rv: RecyclerView
    private lateinit var btnRefresh: Button
    private lateinit var btnReport: Button
    private val job = Job()
    override val coroutineContext: CoroutineContext = Dispatchers.Main + job
    private lateinit var adapter: EmailAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        rv = findViewById(R.id.rvEmails)
        btnRefresh = findViewById(R.id.btnRefresh)
        btnReport = findViewById(R.id.btnRequestReport)
        rv.layoutManager = LinearLayoutManager(this)
        adapter = EmailAdapter(listOf(), this::onMarkSafe, this::onDelete)
        rv.adapter = adapter

        btnRefresh.setOnClickListener { loadEmails() }
        btnReport.setOnClickListener { requestReport() }
        loadEmails()
    }

    private fun loadEmails() {
        launch {
            try {
                val list = withContext(Dispatchers.IO) {
                    RetrofitClient.api.listEmails()
                }
                adapter.update(list)
            } catch (e: Exception) {
                Toast.makeText(this@MainActivity, "Failed to load: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun onMarkSafe(email: SuspiciousEmail) {
        launch {
            try {
                withContext(Dispatchers.IO) {
                    RetrofitClient.api.emailAction(email.id, "mark_safe")
                }
                Toast.makeText(this@MainActivity, "Marked safe", Toast.LENGTH_SHORT).show()
                loadEmails()
            } catch (e: Exception) {
                Toast.makeText(this@MainActivity, "Action failed: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun onDelete(email: SuspiciousEmail) {
        launch {
            try {
                withContext(Dispatchers.IO) {
                    RetrofitClient.api.emailAction(email.id, "delete")
                }
                Toast.makeText(this@MainActivity, "Deleted", Toast.LENGTH_SHORT).show()
                loadEmails()
            } catch (e: Exception) {
                Toast.makeText(this@MainActivity, "Delete failed: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun requestReport() {
        // in a real app you would let user enter an email address. For demo, use configured FROM_EMAIL in backend or prompt.
        val to = "admin@example.com"
        launch {
            try {
                val resp = withContext(Dispatchers.IO) {
                    RetrofitClient.api.requestReport(to)
                }
                if (resp.isSuccessful) {
                    Toast.makeText(this@MainActivity, "Report requested", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(this@MainActivity, "Report request failed: ${resp.code()}", Toast.LENGTH_LONG).show()
                }
            } catch (e: Exception) {
                Toast.makeText(this@MainActivity, "Report failed: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    override fun onDestroy() {
        job.cancel()
        super.onDestroy()
    }
}