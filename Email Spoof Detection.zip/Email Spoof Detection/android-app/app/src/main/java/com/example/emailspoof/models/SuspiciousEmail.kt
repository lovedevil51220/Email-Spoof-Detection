package com.example.emailspoof.models

import com.squareup.moshi.JsonClass

@JsonClass(generateAdapter = true)
data class SuspiciousEmail(
    val id: Int,
    val message_id: String?,
    val subject: String?,
    val sender: String?,
    val from_header: String?,
    val score: Int,
    val reasons: String?,
    val stored_path: String?,
    val reminders_sent: Int,
    val is_deleted: Boolean
)