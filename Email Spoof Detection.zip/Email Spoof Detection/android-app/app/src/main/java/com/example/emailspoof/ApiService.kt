package com.example.emailspoof

import com.example.emailspoof.models.SuspiciousEmail
import retrofit2.Response
import retrofit2.http.*

interface ApiService {
    @GET("emails")
    suspend fun listEmails(): List<SuspiciousEmail>

    @GET("emails/{id}")
    suspend fun getEmail(@Path("id") id: Int): SuspiciousEmail

    @POST("emails/{id}/action")
    @FormUrlEncoded
    suspend fun emailAction(@Path("id") id: Int, @Field("action") action: String): Response<Unit>

    @POST("report")
    @FormUrlEncoded
    suspend fun requestReport(@Field("email_to") emailTo: String): Response<Unit>
}